> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# SOC2 CC6.6 — Boundary protection — restrict access between segments

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-058a0b2b43f6 — Add resource governance to namespace api

severity: low · rule k8s.namespace.no-resource-governance 1.0.0

Namespace api runs 3 long-running workloads (Deployments/StatefulSets/DaemonSets) with no ResourceQuota and no LimitRange object. There is no namespace-level cap on how much CPU or memory the namespace can claim against the cluster, and no LimitRange to supply default per-container requests. Every observed container already sets explicit requests, so the per-pod gap is limited to the absence of a namespace cap and a default-request safety net for future workloads. Note: this is an object-presence check — defaults injected at admission time by a mutating webhook or policy engine (Kyverno, OPA/Gatekeeper) are not visible to a read-only scan and may already govern this namespace; verify before acting.

Evidence:
- namespace api: 3 long-running workloads counted (Deployments/StatefulSets/DaemonSets; Jobs/CronJobs/bare Pods are not counted)
- namespace api: 0 ResourceQuota objects observed
- namespace api: 0 LimitRange objects observed
- all observed containers in this namespace declare explicit CPU/memory requests
- admission/policy-engine-injected defaults (Kyverno, OPA, mutating webhooks) are not observable in a read-only scan and may already govern this namespace

Affected: Namespace api

Rests on reads of: daemonsets, deployments, limitranges, resourcequotas, statefulsets

### f-23977455f4df — Add resource governance to namespace payments

severity: low · rule k8s.namespace.no-resource-governance 1.0.0

Namespace payments runs 3 long-running workloads (Deployments/StatefulSets/DaemonSets) with no ResourceQuota and no LimitRange object. There is no namespace-level cap on how much CPU or memory the namespace can claim against the cluster, and no LimitRange to supply default per-container requests. Every observed container already sets explicit requests, so the per-pod gap is limited to the absence of a namespace cap and a default-request safety net for future workloads. Note: this is an object-presence check — defaults injected at admission time by a mutating webhook or policy engine (Kyverno, OPA/Gatekeeper) are not visible to a read-only scan and may already govern this namespace; verify before acting.

Evidence:
- namespace payments: 3 long-running workloads counted (Deployments/StatefulSets/DaemonSets; Jobs/CronJobs/bare Pods are not counted)
- namespace payments: 0 ResourceQuota objects observed
- namespace payments: 0 LimitRange objects observed
- all observed containers in this namespace declare explicit CPU/memory requests
- admission/policy-engine-injected defaults (Kyverno, OPA, mutating webhooks) are not observable in a read-only scan and may already govern this namespace

Affected: Namespace payments

Rests on reads of: daemonsets, deployments, limitranges, resourcequotas, statefulsets

### f-29e495848160 — Add resource governance to namespace workers

severity: low · rule k8s.namespace.no-resource-governance 1.0.0

Namespace workers runs 4 long-running workloads (Deployments/StatefulSets/DaemonSets) with no ResourceQuota and no LimitRange object. There is no namespace-level cap on how much CPU or memory the namespace can claim against the cluster, and no LimitRange to supply default per-container requests. 1 container here also declare no explicit CPU/memory requests, so without a LimitRange defaultRequest they schedule as BestEffort and have no per-pod floor. Note: this is an object-presence check — defaults injected at admission time by a mutating webhook or policy engine (Kyverno, OPA/Gatekeeper) are not visible to a read-only scan and may already govern this namespace; verify before acting.

Evidence:
- namespace workers: 4 long-running workloads counted (Deployments/StatefulSets/DaemonSets; Jobs/CronJobs/bare Pods are not counted)
- namespace workers: 0 ResourceQuota objects observed
- namespace workers: 0 LimitRange objects observed
- containers with no explicit requests: risk-batch-processor/risk-batch-processor
- admission/policy-engine-injected defaults (Kyverno, OPA, mutating webhooks) are not observable in a read-only scan and may already govern this namespace

Affected: Namespace workers

Rests on reads of: daemonsets, deployments, limitranges, resourcequotas, statefulsets

### f-e399e6ba15a1 — Add resource governance to namespace monitoring

severity: low · rule k8s.namespace.no-resource-governance 1.0.0

Namespace monitoring runs 3 long-running workloads (Deployments/StatefulSets/DaemonSets) with no ResourceQuota and no LimitRange object. There is no namespace-level cap on how much CPU or memory the namespace can claim against the cluster, and no LimitRange to supply default per-container requests. Every observed container already sets explicit requests, so the per-pod gap is limited to the absence of a namespace cap and a default-request safety net for future workloads. Note: this is an object-presence check — defaults injected at admission time by a mutating webhook or policy engine (Kyverno, OPA/Gatekeeper) are not visible to a read-only scan and may already govern this namespace; verify before acting.

Evidence:
- namespace monitoring: 3 long-running workloads counted (Deployments/StatefulSets/DaemonSets; Jobs/CronJobs/bare Pods are not counted)
- namespace monitoring: 0 ResourceQuota objects observed
- namespace monitoring: 0 LimitRange objects observed
- all observed containers in this namespace declare explicit CPU/memory requests
- admission/policy-engine-injected defaults (Kyverno, OPA, mutating webhooks) are not observable in a read-only scan and may already govern this namespace

Affected: Namespace monitoring

Rests on reads of: daemonsets, deployments, limitranges, resourcequotas, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
