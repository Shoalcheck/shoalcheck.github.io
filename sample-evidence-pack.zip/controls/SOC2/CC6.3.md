> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# SOC2 CC6.3 — Logical access — least privilege & role-based authorization

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-54f13d2e24f1 — ClusterRole cluster-admin permits every verb on every resource

severity: high · rule k8s.rbac.dangerous-grant 1.0.0

ClusterRole cluster-admin contains a rule permitting every verb on every resource, and 2 bindings name subjects that activate it. The grant reaches cluster-wide.

Evidence:
- ClusterRole cluster-admin: a rule permits every verb on every resource.
- ClusterRoleBinding acme-break-glass names Group system:masters, and reaches cluster-wide.
- ClusterRoleBinding acme-deployer-cluster-admin names ServiceAccount workers/cicd-deployer, and reaches cluster-wide.

Affected: ClusterRole cluster-admin, ClusterRoleBinding acme-break-glass, ClusterRoleBinding acme-deployer-cluster-admin

Rests on reads of: clusterrolebindings, clusterroles, rolebindings, roles

### f-6033acc002d3 — Review cluster-admin grant on ServiceAccount workers/cicd-deployer

severity: critical · rule k8s.rbac.cluster-admin-serviceaccount 1.0.0

ClusterRoleBinding acme-deployer-cluster-admin binds the cluster-admin ClusterRole (cluster-wide) to 1 ServiceAccount. Every pod running under such an account carries a token with unrestricted API access. The grant itself is a fact; whether it is justified depends on what the workload actually does.

Evidence:
- ClusterRoleBinding acme-deployer-cluster-admin: ServiceAccount workers/cicd-deployer -> cluster-admin
- scope note: matches the built-in ClusterRole "cluster-admin" by name only — custom wildcard (*,*,*) or aggregated ClusterRoles are functionally equivalent but out of scope (role bodies not collected)

Affected: ClusterRoleBinding acme-deployer-cluster-admin, ServiceAccount workers/cicd-deployer

Rests on reads of: clusterrolebindings, rolebindings

### f-95001738e438 — Role acme-api-operator permits every verb on every resource

severity: medium · rule k8s.rbac.dangerous-grant 1.0.0

Role acme-api-operator contains a rule permitting every verb on every resource, and 1 binding name subjects that activate it. The grant reaches within one namespace.

Evidence:
- Role api/acme-api-operator: a rule permits every verb on every resource.
- RoleBinding api/acme-api-operator names ServiceAccount api/api-operator, and reaches within namespace api.

Affected: Role api/acme-api-operator, RoleBinding api/acme-api-operator

Rests on reads of: clusterrolebindings, clusterroles, rolebindings, roles

### f-a8efe8be5bea — ClusterRole acme-secret-sync permits reading Secrets

severity: high · rule k8s.rbac.dangerous-grant 1.0.0

ClusterRole acme-secret-sync contains a rule permitting reading Secrets, and 3 bindings name subjects that activate it. The grant reaches cluster-wide.

Evidence:
- ClusterRole acme-secret-sync: a rule permits reading Secrets.
- Restricted to 2 named objects: acme-pay-oauth-client, acme-pay-stripe-key.
- ClusterRoleBinding acme-everyone-can-read names Group system:authenticated, and reaches cluster-wide.
- ClusterRoleBinding acme-secret-sync names ServiceAccount payments/secret-sync, and reaches cluster-wide.
- RoleBinding workers/acme-legacy-migrator names ServiceAccount workers/acme-migrator-retired, and reaches within namespace workers only, because a RoleBinding scopes a ClusterRole to its own namespace.

Affected: ClusterRole acme-secret-sync, ClusterRoleBinding acme-everyone-can-read, ClusterRoleBinding acme-secret-sync, RoleBinding workers/acme-legacy-migrator

Rests on reads of: clusterrolebindings, clusterroles, rolebindings, roles

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
