> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# SOC2 CC6.1 — Logical access controls restrict unauthorized access

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-0cbb0e17716f — Disable default SA token automount on payments/payments-gateway

severity: low · rule k8s.workload.default-sa-token-automount 1.1.0

Deployment payments/payments-gateway sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment payments/payments-gateway runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in payments (baseline authenticated access only)

Affected: Deployment payments/payments-gateway

Rests on reads of: clusterrolebindings, cronjobs, daemonsets, deployments, jobs, pods, rolebindings, serviceaccounts, statefulsets

### f-25015b652f49 — Enforce non-root at the API for workers/risk-batch-processor (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Deployment workers/risk-batch-processor does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container risk-batch-processor in Deployment workers/risk-batch-processor: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Deployment workers/risk-batch-processor

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-3a2979e97955 — Enforce non-root at the API for workers/acme-schema-migrate-0117 (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Job workers/acme-schema-migrate-0117 does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-schema-migrate-0117: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Job workers/acme-schema-migrate-0117

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-5528a0c3faec — Enforce non-root at the API for default/legacy-cron-runner (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Deployment default/legacy-cron-runner does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container legacy-cron-runner in Deployment default/legacy-cron-runner: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Deployment default/legacy-cron-runner

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-62cc16fb0b88 — Enforce non-root at the API for monitoring/node-exporter (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Deployment monitoring/node-exporter does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container node-exporter in Deployment monitoring/node-exporter: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Deployment monitoring/node-exporter

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-ab2cff4cba76 — Enforce non-root at the API for api/api-gateway (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Deployment api/api-gateway does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container api-gateway in Deployment api/api-gateway: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Deployment api/api-gateway

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-abafc110843a — Enforce non-root at the API for workers/acme-backfill-0114 (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Job workers/acme-backfill-0114 does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-backfill-0114: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Job workers/acme-backfill-0114

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-d28b8e6a4c64 — Enforce non-root at the API for api/auth-service (runAsNonRoot unset)

severity: medium · rule k8s.workload.runs-as-root 1.2.0

Deployment api/auth-service does not enforce non-root execution at the API in 1 of 1 container: runAsNonRoot is unset and no non-zero runAsUser is set. The container image's USER directive is invisible to a read-only API client, so an unset spec is reported as UNCONFIRMED non-root, never "runs as root" — and rated Medium, like the other PSS fields a spec can leave unset. It is rated High only when root is confirmed or near-certain: an explicit runAsUser:0 / runAsNonRoot:false, or a known root-by-default base image with no non-root assertion (each called out per container in the evidence). Set runAsNonRoot:true (and a non-zero runAsUser) on the pod or container securityContext to make non-root intent explicit and admission-enforceable. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container auth-service in Deployment api/auth-service: runAsNonRoot not set and no non-zero runAsUser — unconfirmed non-root (image USER directive is not API-observable)

Affected: Deployment api/auth-service

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
