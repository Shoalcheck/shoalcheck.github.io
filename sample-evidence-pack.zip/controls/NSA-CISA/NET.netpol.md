> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA NET.netpol — Network Separation & Hardening — define NetworkPolicies per namespace

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-0f5d9bf254a2 — Namespace api has no upstream NetworkPolicy — verify its Cilium policy CRDs

severity: low · rule k8s.namespace.no-network-policy 1.0.0

Namespace api runs 3 workloads and defines zero upstream (networking.k8s.io/v1) NetworkPolicy objects. This cluster runs Cilium, which may enforce segmentation through its own CRDs (e.g. CiliumNetworkPolicy / projectcalico.org policies) that shoalcheck does not yet read — so zero upstream objects does NOT prove the namespace is unsegmented. If it is genuinely flat, start with a default-deny-ingress policy, then add explicit allows for the flows that exist.

Evidence:
- namespace api: 3 workloads, 0 networking.k8s.io/v1 NetworkPolicy objects
- detected CNI: Cilium — segmentation may be defined in Cilium policy CRDs that shoalcheck does not read; do not assume flat allow-all

Affected: Namespace api

Rests on reads of: daemonsets, deployments, networkpolicies, server-resources, statefulsets

### f-3a88f9c0cd04 — Namespace monitoring has no upstream NetworkPolicy — verify its Cilium policy CRDs

severity: low · rule k8s.namespace.no-network-policy 1.0.0

Namespace monitoring runs 3 workloads and defines zero upstream (networking.k8s.io/v1) NetworkPolicy objects. This cluster runs Cilium, which may enforce segmentation through its own CRDs (e.g. CiliumNetworkPolicy / projectcalico.org policies) that shoalcheck does not yet read — so zero upstream objects does NOT prove the namespace is unsegmented. If it is genuinely flat, start with a default-deny-ingress policy, then add explicit allows for the flows that exist.

Evidence:
- namespace monitoring: 3 workloads, 0 networking.k8s.io/v1 NetworkPolicy objects
- detected CNI: Cilium — segmentation may be defined in Cilium policy CRDs that shoalcheck does not read; do not assume flat allow-all

Affected: Namespace monitoring

Rests on reads of: daemonsets, deployments, networkpolicies, server-resources, statefulsets

### f-7cb250877d80 — Namespace workers has no upstream NetworkPolicy — verify its Cilium policy CRDs

severity: low · rule k8s.namespace.no-network-policy 1.0.0

Namespace workers runs 4 workloads and defines zero upstream (networking.k8s.io/v1) NetworkPolicy objects. This cluster runs Cilium, which may enforce segmentation through its own CRDs (e.g. CiliumNetworkPolicy / projectcalico.org policies) that shoalcheck does not yet read — so zero upstream objects does NOT prove the namespace is unsegmented. If it is genuinely flat, start with a default-deny-ingress policy, then add explicit allows for the flows that exist.

Evidence:
- namespace workers: 4 workloads, 0 networking.k8s.io/v1 NetworkPolicy objects
- detected CNI: Cilium — segmentation may be defined in Cilium policy CRDs that shoalcheck does not read; do not assume flat allow-all

Affected: Namespace workers

Rests on reads of: daemonsets, deployments, networkpolicies, server-resources, statefulsets

### f-f04606ed1db1 — Namespace payments has no upstream NetworkPolicy — verify its Cilium policy CRDs

severity: low · rule k8s.namespace.no-network-policy 1.0.0

Namespace payments runs 3 workloads and defines zero upstream (networking.k8s.io/v1) NetworkPolicy objects. This cluster runs Cilium, which may enforce segmentation through its own CRDs (e.g. CiliumNetworkPolicy / projectcalico.org policies) that shoalcheck does not yet read — so zero upstream objects does NOT prove the namespace is unsegmented. If it is genuinely flat, start with a default-deny-ingress policy, then add explicit allows for the flows that exist.

Evidence:
- namespace payments: 3 workloads, 0 networking.k8s.io/v1 NetworkPolicy objects
- detected CNI: Cilium — segmentation may be defined in Cilium policy CRDs that shoalcheck does not read; do not assume flat allow-all

Affected: Namespace payments

Rests on reads of: daemonsets, deployments, networkpolicies, server-resources, statefulsets

### f-f6611ef63287 — Namespace default has no upstream NetworkPolicy — verify its Cilium policy CRDs

severity: low · rule k8s.namespace.no-network-policy 1.0.0

Namespace default runs 1 workload and defines zero upstream (networking.k8s.io/v1) NetworkPolicy objects. This cluster runs Cilium, which may enforce segmentation through its own CRDs (e.g. CiliumNetworkPolicy / projectcalico.org policies) that shoalcheck does not yet read — so zero upstream objects does NOT prove the namespace is unsegmented. If it is genuinely flat, start with a default-deny-ingress policy, then add explicit allows for the flows that exist.

Evidence:
- namespace default: 1 workload, 0 networking.k8s.io/v1 NetworkPolicy objects
- detected CNI: Cilium — segmentation may be defined in Cilium policy CRDs that shoalcheck does not read; do not assume flat allow-all

Affected: Namespace default

Rests on reads of: daemonsets, deployments, networkpolicies, server-resources, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
