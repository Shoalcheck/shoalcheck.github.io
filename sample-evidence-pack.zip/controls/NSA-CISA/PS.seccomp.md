> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA PS.seccomp — Pod Security — apply a seccomp profile

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-59afb6e6f75e — Enforce a seccomp profile on api/auth-service

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Deployment api/auth-service has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container auth-service in Deployment api/auth-service: no seccompProfile set (effective: unset)

Affected: Deployment api/auth-service

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-65f891f945c8 — Enforce a seccomp profile on workers/acme-backfill-0114

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Job workers/acme-backfill-0114 has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-backfill-0114: no seccompProfile set (effective: unset)

Affected: Job workers/acme-backfill-0114

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-80bdb1b2f68e — Enforce a seccomp profile on workers/risk-batch-processor

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Deployment workers/risk-batch-processor has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container risk-batch-processor in Deployment workers/risk-batch-processor: no seccompProfile set (effective: unset)

Affected: Deployment workers/risk-batch-processor

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-834552715068 — Enforce a seccomp profile on workers/acme-schema-migrate-0117

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Job workers/acme-schema-migrate-0117 has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-schema-migrate-0117: no seccompProfile set (effective: unset)

Affected: Job workers/acme-schema-migrate-0117

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-be46eee477f5 — Enforce a seccomp profile on monitoring/node-exporter

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Deployment monitoring/node-exporter has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container node-exporter in Deployment monitoring/node-exporter: no seccompProfile set (effective: unset)

Affected: Deployment monitoring/node-exporter

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-c8d39771bd4f — Enforce a seccomp profile on default/legacy-cron-runner

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Deployment default/legacy-cron-runner has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container legacy-cron-runner in Deployment default/legacy-cron-runner: no seccompProfile set (effective: unset)

Affected: Deployment default/legacy-cron-runner

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-e768b03693f6 — Enforce a seccomp profile on api/api-gateway

severity: medium · rule k8s.workload.seccomp-not-enforced 1.2.0

Deployment api/api-gateway has 1 of 1 container whose effective seccompProfile is unset or Unconfined (computed pod then container). Set seccompProfile.type:RuntimeDefault at the pod level so every container inherits syscall filtering — required by PSS-Restricted (CIS 5.7.2 maps to 5.2.1 in this benchmark version). This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container api-gateway in Deployment api/api-gateway: no seccompProfile set (effective: unset)

Affected: Deployment api/api-gateway

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
