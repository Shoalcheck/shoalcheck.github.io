> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA PS.privileged — Pod Security — reject privileged / host-namespace pods

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-e4bf52323dca — Confirm host access is expected for monitoring/node-exporter

severity: low · rule k8s.workload.privileged-host-access 1.3.0

Deployment monitoring/node-exporter requests privileged or host-level access (3 items: see evidence). Unless this workload IS node infrastructure (CNI, runtime agent, node exporter, CSI driver), drop privileged:true from container securityContexts, set hostNetwork/hostPID/hostIPC to false, and replace hostPath volumes with PVCs, ConfigMaps, or the downward API. The fix is app-specific, so no generic patch is offered — the command below pinpoints each offending line. Read-only and type-scoped hostPath mounts are materially lower risk than writable mounts of sensitive paths (e.g. docker.sock, /, /etc) — see the per-volume evidence for which kind each is. This workload matches a known node-infrastructure pattern (node-exporter); for those, host/privileged access is by design and removing it will break the agent — this finding is informational, confirm rather than remediate.

Evidence:
- NOTE: matches a well-known node-infrastructure pattern (node-exporter) — host/privileged access is expected for this class of workload; verify it is the agent it appears to be before treating as a misconfiguration.
- container node-exporter in Deployment monitoring/node-exporter: privileged=true
- Deployment monitoring/node-exporter: hostNetwork=true

Affected: Deployment monitoring/node-exporter

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
