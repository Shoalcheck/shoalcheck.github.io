> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA UPG.image-hygiene — Upgrading & Application Security — image hygiene (partial; full coverage needs a scanner)

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-ec803c18cdf7 — Pin mutable image references on api/api-gateway

severity: medium · rule k8s.workload.mutable-image-tags 1.1.0

Deployment api/api-gateway has 1 image reference that can resolve to different bytes on different pulls. The same manifest may then run different code across nodes or after a restart, which breaks rollbacks and makes incident forensics guesswork. Pin a specific version tag or, for true immutability, a digest (@sha256:…). On a genuinely fixed tag, imagePullPolicy=IfNotPresent is then safe.

Evidence:
- container api-gateway: image registry.acme.example/api-gateway:latest (mutable :latest tag)

Affected: Deployment api/api-gateway

Rests on reads of: daemonsets, deployments, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
