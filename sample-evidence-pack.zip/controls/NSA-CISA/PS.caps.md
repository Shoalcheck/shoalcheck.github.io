> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA PS.caps — Pod Security — drop unnecessary Linux capabilities

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-1b3ebe017313 — Drop ALL capabilities then add back only what api/api-gateway needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Deployment api/api-gateway has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container api-gateway in Deployment api/api-gateway: capabilities.drop does not include ALL

Affected: Deployment api/api-gateway

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-7805896c58c6 — Drop ALL capabilities then add back only what workers/acme-schema-migrate-0117 needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Job workers/acme-schema-migrate-0117 has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-schema-migrate-0117: capabilities.drop does not include ALL

Affected: Job workers/acme-schema-migrate-0117

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-787835dc1449 — Drop ALL capabilities then add back only what monitoring/node-exporter needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Deployment monitoring/node-exporter has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container node-exporter in Deployment monitoring/node-exporter: capabilities.drop does not include ALL

Affected: Deployment monitoring/node-exporter

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-7cc03878e386 — Drop ALL capabilities then add back only what workers/risk-batch-processor needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Deployment workers/risk-batch-processor has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container risk-batch-processor in Deployment workers/risk-batch-processor: capabilities.drop does not include ALL

Affected: Deployment workers/risk-batch-processor

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-c1629f6ae3df — Drop ALL capabilities then add back only what api/auth-service needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Deployment api/auth-service has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container auth-service in Deployment api/auth-service: capabilities.drop does not include ALL

Affected: Deployment api/auth-service

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-d42312238aea — Drop ALL capabilities then add back only what workers/acme-backfill-0114 needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Job workers/acme-backfill-0114 has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-backfill-0114: capabilities.drop does not include ALL

Affected: Job workers/acme-backfill-0114

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-e17c526caece — Drop ALL capabilities then add back only what default/legacy-cron-runner needs

severity: medium · rule k8s.workload.capabilities-not-dropped 1.2.0

Deployment default/legacy-cron-runner has 1 of 1 container that do not drop ALL capabilities, so each keeps the default Linux capability set (NET_RAW included). The PSS-Restricted profile requires capabilities.drop:[ALL]; add back only NET_BIND_SERVICE if the container binds a privileged port. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container legacy-cron-runner in Deployment default/legacy-cron-runner: capabilities.drop does not include ALL

Affected: Deployment default/legacy-cron-runner

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
