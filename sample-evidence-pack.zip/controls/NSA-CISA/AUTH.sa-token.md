> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA AUTH.sa-token — Authentication & Authorization — disable default ServiceAccount token automount

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-0cbb0e17716f — Disable default SA token automount on payments/payments-gateway

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment payments/payments-gateway sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment payments/payments-gateway runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in payments (baseline authenticated access only)

Affected: Deployment payments/payments-gateway

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-1ce1b4c10535 — Disable default SA token automount on workers/webhook-dispatcher

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment workers/webhook-dispatcher sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment workers/webhook-dispatcher runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in workers (baseline authenticated access only)

Affected: Deployment workers/webhook-dispatcher

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-1d2d72d53137 — Disable default SA token automount on api/search-indexer

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment api/search-indexer sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment api/search-indexer runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in api (baseline authenticated access only)

Affected: Deployment api/search-indexer

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-507584056829 — Disable default SA token automount on api/auth-service

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment api/auth-service sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment api/auth-service runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in api (baseline authenticated access only)

Affected: Deployment api/auth-service

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-6a299ed4fbf0 — Disable default SA token automount on default/legacy-cron-runner

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment default/legacy-cron-runner sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment default/legacy-cron-runner runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in default (baseline authenticated access only)

Affected: Deployment default/legacy-cron-runner

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-990a9d899da0 — Disable default SA token automount on workers/ledger-reconciler

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment workers/ledger-reconciler sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment workers/ledger-reconciler runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in workers (baseline authenticated access only)

Affected: Deployment workers/ledger-reconciler

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-b7a81b6c303a — Disable default SA token automount on monitoring/node-exporter

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment monitoring/node-exporter sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment monitoring/node-exporter runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in monitoring (baseline authenticated access only)

Affected: Deployment monitoring/node-exporter

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

### f-d3245733acee — Disable default SA token automount on payments/payments-orchestrator

severity: low · rule k8s.workload.default-sa-token-automount 1.0.0

Deployment payments/payments-orchestrator sets no dedicated ServiceAccount and mounts the default SA's API token into every container. No RoleBinding or ClusterRoleBinding observed in this cluster references this namespace's default SA, so the token grants only baseline authenticated/discovery access today — but any future RoleBinding silently widens this exposure to every pod already on the default SA. If this workload does need API access, give it a dedicated ServiceAccount with a scoped Role instead. Exception: if this pod uses the projected token for cloud IAM (EKS IRSA / Pod Identity, GKE Workload Identity), disabling automount will break that — give it a dedicated SA configured for the integration instead of turning the token off.

Evidence:
- Deployment payments/payments-orchestrator runs as default SA with token automounted
- no Role/ClusterRole binding observed references the default SA in payments (baseline authenticated access only)

Affected: Deployment payments/payments-orchestrator

Rests on reads of: clusterrolebindings, daemonsets, deployments, rolebindings, serviceaccounts, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
