> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# NSA-CISA PS.rofs — Pod Security — use an immutable (read-only) root filesystem

Status: observations mapped; no machine status exists for this framework — Shoalcheck computes none for SOC 2, PCI DSS or NSA-CISA

## Observations mapped to this control

### f-3807c1165d1b — Make the root filesystem read-only for workers/acme-schema-migrate-0117

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Job workers/acme-schema-migrate-0117 has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-schema-migrate-0117: readOnlyRootFilesystem not set to true

Affected: Job workers/acme-schema-migrate-0117

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-4599bbcbc538 — Make the root filesystem read-only for workers/acme-backfill-0114

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Job workers/acme-backfill-0114 has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container migrate in Job workers/acme-backfill-0114: readOnlyRootFilesystem not set to true

Affected: Job workers/acme-backfill-0114

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-4a5d593fb699 — Make the root filesystem read-only for workers/risk-batch-processor

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Deployment workers/risk-batch-processor has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container risk-batch-processor in Deployment workers/risk-batch-processor: readOnlyRootFilesystem not set to true

Affected: Deployment workers/risk-batch-processor

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-5004381bb1d3 — Make the root filesystem read-only for default/legacy-cron-runner

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Deployment default/legacy-cron-runner has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container legacy-cron-runner in Deployment default/legacy-cron-runner: readOnlyRootFilesystem not set to true

Affected: Deployment default/legacy-cron-runner

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-a4c78812a9e5 — Make the root filesystem read-only for api/api-gateway

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Deployment api/api-gateway has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container api-gateway in Deployment api/api-gateway: readOnlyRootFilesystem not set to true

Affected: Deployment api/api-gateway

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-d5596225b087 — Make the root filesystem read-only for api/auth-service

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Deployment api/auth-service has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container auth-service in Deployment api/auth-service: readOnlyRootFilesystem not set to true

Affected: Deployment api/auth-service

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

### f-fb263a044542 — Make the root filesystem read-only for monitoring/node-exporter

severity: low · rule k8s.workload.writable-root-filesystem 1.2.0

Deployment monitoring/node-exporter has 1 of 1 container without a read-only root filesystem. Note: PSS does NOT require this (it is a hardening extension, not part of the Baseline or Restricted profile), so this is a Low-severity defense-in-depth suggestion — set readOnlyRootFilesystem:true and mount writable paths as emptyDir/PVC volumes where the app genuinely needs to write. This reads the spec AS AUTHORED, not as admitted: a PodSecurity admission profile or mutating webhook could reject or fill this field at admission time. Read alongside the namespace's PodSecurity admission level (k8s.namespace.pss-admission-not-enforced) to know whether the cluster actually enforces it.

Evidence:
- container node-exporter in Deployment monitoring/node-exporter: readOnlyRootFilesystem not set to true

Affected: Deployment monitoring/node-exporter

Rests on reads of: cronjobs, daemonsets, deployments, jobs, pods, statefulsets

## What this reading could not examine for this control

Nothing the mapped checks rest on was refused.
