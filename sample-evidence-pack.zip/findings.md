> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# Audit findings — acme-pay-prod

141 finding(s), highest severity first.

| ID | Severity | Category | Title | $/mo | Effort | Rule | Affected |
| -- | -------- | -------- | ----- | ---- | ------ | ---- | -------- |
| f-6033acc002d3 | critical | security | Review cluster-admin grant on ServiceAccount workers/cicd-deployer | — | high | k8s.rbac.cluster-admin-serviceaccount | ClusterRoleBinding/acme-deployer-cluster-admin; ServiceAccount/workers/cicd-deployer |
| f-1dec706d3b80 | high | reliability | No ready address is published for api/api-gateway | — | low | k8s.reliability.service-no-ready-endpoints | Service/api/api-gateway |
| f-2345f2b5c939 | high | reliability | No ready address is published for payments/old-admin-lb | — | low | k8s.reliability.service-no-ready-endpoints | Service/payments/old-admin-lb |
| f-3a00f5538dd0 | high | reliability | Single replica without PDB: monitoring/prometheus-k8s | — | medium | k8s.workload.single-replica-no-pdb | StatefulSet/monitoring/prometheus-k8s |
| f-3bd52b116bda | high | reliability | Losing zone eu-central-1a leaves 2 pods with no node this model accepts | — | high | k8s.reliability.zone-loss-feasibility | Pod/payments/payments-ledger-db-0; Pod/workers/licensed-etl-0 |
| f-3c8cba621747 | high | security | ClusterRoleBinding acme-break-glass binds Group system:masters | — | medium | k8s.rbac.binding-to-builtin-subject | ClusterRoleBinding/acme-break-glass |
| f-54f13d2e24f1 | high | security | ClusterRole cluster-admin permits every verb on every resource | — | medium | k8s.rbac.dangerous-grant | ClusterRole/cluster-admin; ClusterRoleBinding/acme-break-glass; ClusterRoleBinding/acme-deployer-cluster-admin |
| f-8a4946523606 | high | reliability | No ready address is published for payments/legacy-checkout-lb | — | low | k8s.reliability.service-no-ready-endpoints | Service/payments/legacy-checkout-lb |
| f-8a9c190a59a5 | high | reliability | A node roll meets 5 of 12 nodes it cannot evacuate | — | high | k8s.upgrade.node-pool-cannot-roll | Node/ip-10-0-1-a; Node/ip-10-0-1-b; Node/ip-10-0-1-c; Node/ip-10-0-1-d; Node/ip-10-0-2-a |
| f-a8efe8be5bea | high | security | ClusterRole acme-secret-sync permits reading Secrets | — | medium | k8s.rbac.dangerous-grant | ClusterRole/acme-secret-sync; ClusterRoleBinding/acme-everyone-can-read; ClusterRoleBinding/acme-secret-sync; RoleBinding/workers/acme-legacy-migrator |
| f-c886fc0b97a6 | high | reliability | No ready address is published for payments/legacy-payments-lb | — | low | k8s.reliability.service-no-ready-endpoints | Service/payments/legacy-payments-lb |
| f-1904067e5f55 | medium | cost | Kubernetes 1.31 is past AWS's ordinary support window | $365 | high | k8s.cost.kubernetes-version-past-standard-support | Cluster/1.31 |
| f-b76762a637f1 | medium | cost | Right-size over-provisioned requests on workers/webhook-dispatcher | $300 | low | k8s.cost.overprovisioned-resources | Deployment/workers/webhook-dispatcher |
| f-bbb7fb66d3c2 | medium | cost | Right-size over-provisioned requests on workers/ledger-reconciler | $210 | low | k8s.cost.overprovisioned-resources | Deployment/workers/ledger-reconciler |
| f-320f01c079a1 | medium | cost | Right-size over-provisioned requests on api/search-indexer | $112 | low | k8s.cost.overprovisioned-resources | Deployment/api/search-indexer |
| f-65e23c8822dd | medium | cost | Right-size over-provisioned requests on payments/payments-orchestrator | $75 | low | k8s.cost.overprovisioned-resources | Deployment/payments/payments-orchestrator |
| f-84f33e0e702b | medium | cost | Right-size over-provisioned requests on api/api-gateway | $25 | low | k8s.cost.overprovisioned-resources | Deployment/api/api-gateway |
| f-850875e6f8e6 | medium | cost | Idle LoadBalancer: payments/legacy-payments-lb has no backends | $20 | low | k8s.cost.idle-loadbalancer | Service/payments/legacy-payments-lb |
| f-d4be978b6bef | medium | cost | Idle LoadBalancer: payments/old-admin-lb has no backends | $20 | low | k8s.cost.idle-loadbalancer | Service/payments/old-admin-lb |
| f-f06f81303d54 | medium | cost | Idle LoadBalancer: payments/legacy-checkout-lb has no backends | $20 | low | k8s.cost.idle-loadbalancer | Service/payments/legacy-checkout-lb |
| f-aef94b13aab4 | medium | cost | Right-size over-provisioned requests on payments/payments-gateway | $12 | low | k8s.cost.overprovisioned-resources | Deployment/payments/payments-gateway |
| f-b2754432151e | medium | cost | Right-size over-provisioned requests on payments/payments-ledger-db | $12 | low | k8s.cost.overprovisioned-resources | StatefulSet/payments/payments-ledger-db |
| f-f555739b377e | medium | cost | Right-size over-provisioned requests on monitoring/prometheus-k8s | $12 | low | k8s.cost.overprovisioned-resources | StatefulSet/monitoring/prometheus-k8s |
| f-d0e911c264d1 | medium | cost | Right-size over-provisioned requests on api/auth-service | $12 | low | k8s.cost.overprovisioned-resources | Deployment/api/auth-service |
| f-0b11a8574f11 | medium | cost | Right-size over-provisioned requests on workers/licensed-etl | $6 | low | k8s.cost.overprovisioned-resources | StatefulSet/workers/licensed-etl |
| f-02bbe964dbd4 | medium | security | Enforce a PodSecurity admission profile on namespace default | — | low | k8s.namespace.pss-admission-not-enforced | Namespace/default |
| f-07655d07be70 | medium | reliability | CronJob workers/acme-nightly-reconcile recorded no success inside the 7d window | — | low | k8s.reliability.cronjob-no-recent-success | CronJob/workers/acme-nightly-reconcile |
| f-08eb4b10be4b | medium | reliability | Deployment payments/payments-orchestrator has 2 of 3 replicas ready | — | medium | k8s.reliability.replicas-below-desired | Deployment/payments/payments-orchestrator |
| f-0ac91964537b | medium | security | Enforce a PodSecurity admission profile on namespace monitoring | — | low | k8s.namespace.pss-admission-not-enforced | Namespace/monitoring |
| f-1b3ebe017313 | medium | security | Drop ALL capabilities then add back only what api/api-gateway needs | — | low | k8s.workload.capabilities-not-dropped | Deployment/api/api-gateway |
| f-23cd731c738c | medium | config | A probe on Deployment api/api-gateway targets an undeclared port | — | low | k8s.config.probe-port-not-declared | Deployment/api/api-gateway |
| f-2460b2193ffd | medium | reliability | Spread workers/ledger-reconciler replicas across nodes | — | low | k8s.workload.no-anti-affinity | Deployment/workers/ledger-reconciler |
| f-25015b652f49 | medium | security | Enforce non-root at the API for workers/risk-batch-processor (runAsNonRoot unset) | — | medium | k8s.workload.runs-as-root | Deployment/workers/risk-batch-processor |
| f-286e1369a764 | medium | reliability | Spread payments/payments-orchestrator replicas across nodes | — | low | k8s.workload.no-anti-affinity | Deployment/payments/payments-orchestrator |
| f-2b90e41e773a | medium | reliability | Node ip-10-0-2-b has read DiskPressure=True since 2026-07-15T04:20:00Z | — | medium | k8s.reliability.condition-unchanged | Node/ip-10-0-2-b |
| f-2b9f8a33905b | medium | config | PVC payments/data-payments-ledger-db-0 names a StorageClass this reading did not find | — | medium | k8s.config.storageclass-unresolved | PersistentVolumeClaim/payments/data-payments-ledger-db-0 |
| f-342b2f4d7fb8 | medium | config | Ingress api/acme-public names a backend that resolves to nothing | — | low | k8s.config.ingress-backend-unresolved | Ingress/api/acme-public; Service/api/api-gateway |
| f-409d1b10d7e2 | medium | reliability | This cluster's monitoring cannot reach 2 of its 55 scrape targets | — | low | k8s.observed.scrape-targets-down |  |
| f-4103b7675e51 | medium | config | Deployment api/api-gateway runs 2 different builds of registry.acme.example/api-gateway:latest | — | low | k8s.workload.image-digest-drift | Pod/api/api-gateway-7f4b9c0-a; Pod/api/api-gateway-7f4b9c1-b |
| f-44531237a3ea | medium | reliability | Losing node ip-10-0-2-a leaves 1 pod with no node this model accepts | — | medium | k8s.reliability.node-loss-feasibility | Pod/workers/licensed-etl-0 |
| f-486e5cb98fc5 | medium | reliability | Drain of ip-10-0-1-c: budget payments/payments-orchestrator-pdb is at zero right now | — | medium | k8s.reliability.node-drain-budget | Node/ip-10-0-1-c; PodDisruptionBudget/payments/payments-orchestrator-pdb |
| f-48801d2358ee | medium | config | Ingress api/acme-public names an IngressClass this reading did not find | — | low | k8s.config.ingressclass-unresolved | Ingress/api/acme-public |
| f-48b08a5999b7 | medium | security | Enforce a PodSecurity admission profile on namespace api | — | low | k8s.namespace.pss-admission-not-enforced | Namespace/api |
| f-4f927b28b036 | medium | config | 3 pods in payments are covered by 2 PodDisruptionBudgets | — | low | k8s.config.pod-covered-by-two-pdbs | PodDisruptionBudget/payments/acme-platform-baseline; PodDisruptionBudget/payments/payments-orchestrator-pdb; Pod/payments/payments-orchestrator-7f4b9c0-a; Pod/payments/payments-orchestrator-7f4b9c1-b; Pod/payments/payments-orchestrator-7f4b9c2-c |
| f-539cf71c68b7 | medium | reliability | Drain of ip-10-0-1-b: budget payments/payments-orchestrator-pdb is at zero right now | — | medium | k8s.reliability.node-drain-budget | Node/ip-10-0-1-b; PodDisruptionBudget/payments/payments-orchestrator-pdb |
| f-54462bd924c3 | medium | security | Disable privilege escalation for workers/risk-batch-processor | — | low | k8s.workload.allow-privilege-escalation | Deployment/workers/risk-batch-processor |
| f-5528a0c3faec | medium | security | Enforce non-root at the API for default/legacy-cron-runner (runAsNonRoot unset) | — | medium | k8s.workload.runs-as-root | Deployment/default/legacy-cron-runner |
| f-59afb6e6f75e | medium | security | Enforce a seccomp profile on api/auth-service | — | low | k8s.workload.seccomp-not-enforced | Deployment/api/auth-service |
| f-5ca79ff7752f | medium | reliability | 1 pod of Deployment default/legacy-cron-runner is not ready | — | medium | k8s.reliability.pod-not-ready | Pod/default/legacy-cron-runner-7f4b9c0-a |
| f-62cc16fb0b88 | medium | security | Enforce non-root at the API for monitoring/node-exporter (runAsNonRoot unset) | — | medium | k8s.workload.runs-as-root | Deployment/monitoring/node-exporter |
| f-6cd65827cd51 | medium | reliability | Spread workers/risk-batch-processor replicas across nodes | — | low | k8s.workload.no-anti-affinity | Deployment/workers/risk-batch-processor |
| f-6cf812a096d9 | medium | reliability | Spread api/auth-service replicas across nodes | — | low | k8s.workload.no-anti-affinity | Deployment/api/auth-service |
| f-71076a148653 | medium | reliability | PVC payments/data-payments-ledger-db-0 holds 50Gi and asks for 100Gi | — | medium | k8s.reliability.pvc-below-request | PersistentVolumeClaim/payments/data-payments-ledger-db-0 |
| f-719907e2e77b | medium | security | ClusterRoleBinding acme-everyone-can-read binds Group system:authenticated | — | medium | k8s.rbac.binding-to-builtin-subject | ClusterRoleBinding/acme-everyone-can-read |
| f-787835dc1449 | medium | security | Drop ALL capabilities then add back only what monitoring/node-exporter needs | — | low | k8s.workload.capabilities-not-dropped | Deployment/monitoring/node-exporter |
| f-7abfd8902b1e | medium | reliability | 1 alerting rule in this cluster is firing right now | — | medium | k8s.observed.alerts-firing |  |
| f-7cc03878e386 | medium | security | Drop ALL capabilities then add back only what workers/risk-batch-processor needs | — | low | k8s.workload.capabilities-not-dropped | Deployment/workers/risk-batch-processor |
| f-80bdb1b2f68e | medium | security | Enforce a seccomp profile on workers/risk-batch-processor | — | low | k8s.workload.seccomp-not-enforced | Deployment/workers/risk-batch-processor |
| f-883b67775cc6 | medium | config | Deployment api/api-gateway spreads across a label no node carries | — | low | k8s.config.topology-key-no-node-carries | Deployment/api/api-gateway |
| f-8b41daa3737b | medium | reliability | Spread workers/webhook-dispatcher replicas across nodes | — | low | k8s.workload.no-anti-affinity | Deployment/workers/webhook-dispatcher |
| f-8bc1b4db3ed8 | medium | security | Disable privilege escalation for api/api-gateway | — | low | k8s.workload.allow-privilege-escalation | Deployment/api/api-gateway |
| f-8bcd0694256d | medium | reliability | Spread monitoring/node-exporter replicas across nodes | — | low | k8s.workload.no-anti-affinity | Deployment/monitoring/node-exporter |
| f-8c3c1843022e | medium | config | StatefulSet payments/payments-ledger-db names a governing Service this reading did not find | — | low | k8s.config.governing-service-unresolved | StatefulSet/payments/payments-ledger-db |
| f-8d032a251da3 | medium | config | Deployment workers/webhook-dispatcher names a PriorityClass this reading did not find | — | low | k8s.config.priorityclass-unresolved | Deployment/workers/webhook-dispatcher |
| f-94525e3578be | medium | security | Disable privilege escalation for default/legacy-cron-runner | — | low | k8s.workload.allow-privilege-escalation | Deployment/default/legacy-cron-runner |
| f-95001738e438 | medium | security | Role acme-api-operator permits every verb on every resource | — | medium | k8s.rbac.dangerous-grant | Role/api/acme-api-operator; RoleBinding/api/acme-api-operator |
| f-a134d5855b6d | medium | config | Deployment api/search-indexer spreads across a label no node carries | — | low | k8s.config.topology-key-no-node-carries | Deployment/api/search-indexer |
| f-aa536944aca2 | medium | config | HorizontalPodAutoscaler api/auth-service-v1 names a Deployment this reading did not find | — | low | k8s.config.hpa-target-unresolved | HorizontalPodAutoscaler/api/auth-service-v1 |
| f-ab2cff4cba76 | medium | security | Enforce non-root at the API for api/api-gateway (runAsNonRoot unset) | — | medium | k8s.workload.runs-as-root | Deployment/api/api-gateway |
| f-ac220240ba62 | medium | config | Deployment workers/risk-batch-processor names a ServiceAccount this reading did not find | — | low | k8s.config.serviceaccount-unresolved | Deployment/workers/risk-batch-processor |
| f-be46eee477f5 | medium | security | Enforce a seccomp profile on monitoring/node-exporter | — | low | k8s.workload.seccomp-not-enforced | Deployment/monitoring/node-exporter |
| f-bff0772f646f | medium | reliability | Drain of ip-10-0-1-a stops on 1 pod no controller manages | — | low | k8s.reliability.node-drain-unmanaged-pod | Node/ip-10-0-1-a; Pod/workers/debug-shell-ondemand |
| f-c1629f6ae3df | medium | security | Drop ALL capabilities then add back only what api/auth-service needs | — | low | k8s.workload.capabilities-not-dropped | Deployment/api/auth-service |
| f-c8d39771bd4f | medium | security | Enforce a seccomp profile on default/legacy-cron-runner | — | low | k8s.workload.seccomp-not-enforced | Deployment/default/legacy-cron-runner |
| f-d197f23cd6b4 | medium | security | Enforce a PodSecurity admission profile on namespace workers | — | low | k8s.namespace.pss-admission-not-enforced | Namespace/workers |
| f-d28b8e6a4c64 | medium | security | Enforce non-root at the API for api/auth-service (runAsNonRoot unset) | — | medium | k8s.workload.runs-as-root | Deployment/api/auth-service |
| f-d5389700eafb | medium | security | Disable privilege escalation for api/auth-service | — | low | k8s.workload.allow-privilege-escalation | Deployment/api/auth-service |
| f-d811265f3b7b | medium | reliability | Deployment workers/ledger-reconciler runs 4 replicas against a volume that permits one node | — | medium | k8s.reliability.rwo-volume-shared | Deployment/workers/ledger-reconciler; PersistentVolumeClaim/workers/ledger-reconciler-work |
| f-d98a27393c6c | medium | reliability | Deployment default/legacy-cron-runner has a container restarted 37 times | — | medium | k8s.reliability.container-restart-total | Pod/default/legacy-cron-runner-7f4b9c0-a |
| f-db75a71804cf | medium | config | 1 served API version is removed by Kubernetes 1.32 or later | — | medium | k8s.upgrade.deprecated-api-served | APIService/flowcontrol.apiserver.k8s.io/v1beta3 |
| f-dc9aaec3117c | medium | config | Service api/api-gateway targets a port name its pods do not declare | — | low | k8s.config.service-targetport-undeclared | Service/api/api-gateway |
| f-dd8a6d656535 | medium | security | Disable privilege escalation for monitoring/node-exporter | — | low | k8s.workload.allow-privilege-escalation | Deployment/monitoring/node-exporter |
| f-e17c526caece | medium | security | Drop ALL capabilities then add back only what default/legacy-cron-runner needs | — | low | k8s.workload.capabilities-not-dropped | Deployment/default/legacy-cron-runner |
| f-e768b03693f6 | medium | security | Enforce a seccomp profile on api/api-gateway | — | low | k8s.workload.seccomp-not-enforced | Deployment/api/api-gateway |
| f-e8ceeb23689a | medium | reliability | Drain of ip-10-0-1-d: budget payments/payments-orchestrator-pdb is at zero right now | — | medium | k8s.reliability.node-drain-budget | Node/ip-10-0-1-d; PodDisruptionBudget/payments/payments-orchestrator-pdb |
| f-ea56e4e5723c | medium | security | Enforce a PodSecurity admission profile on namespace payments | — | low | k8s.namespace.pss-admission-not-enforced | Namespace/payments |
| f-ec803c18cdf7 | medium | config | Pin mutable image references on api/api-gateway | — | low | k8s.workload.mutable-image-tags | Deployment/api/api-gateway |
| f-f346f70bae06 | medium | security | RoleBinding workers/acme-legacy-migrator grants to a ServiceAccount that is not there | — | low | k8s.rbac.binding-subject-unresolved | RoleBinding/workers/acme-legacy-migrator |
| f-f493305a0158 | medium | reliability | A volume ties payments/payments-ledger-db-0 to zone eu-central-1a | — | high | k8s.reliability.zone-pinned-volume | Pod/payments/payments-ledger-db-0 |
| f-fd12da5d9579 | medium | config | Set resource requests on workers/risk-batch-processor | — | low | k8s.workload.missing-resource-requests | Deployment/workers/risk-batch-processor |
| f-ff3e0a795312 | medium | reliability | HPA payments/payments-orchestrator may scale payments-orchestrator to 2 while PDB payments-orchestrator-pdb requires 3 available | — | low | k8s.reliability.autoscaler-floor-below-budget | HorizontalPodAutoscaler/payments/payments-orchestrator; PodDisruptionBudget/payments/payments-orchestrator-pdb; Deployment/payments/payments-orchestrator |
| f-f7b465708dc1 | low | cost | 3 r6i.4xlarge nodes list 10% above r6a.4xlarge, an equivalent x86 shape | $266 | medium | k8s.cost.instance-generation-lag | Node/ip-10-0-2-a; Node/ip-10-0-2-b; Node/ip-10-0-2-c |
| f-9501d56c54d5 | low | cost | 9 m6i.xlarge nodes list 10% above m6a.xlarge, an equivalent x86 shape | $151 | medium | k8s.cost.instance-generation-lag | Node/ip-10-0-1-a; Node/ip-10-0-1-b; Node/ip-10-0-1-c; Node/ip-10-0-1-d; Node/ip-10-0-1-e; Node/ip-10-0-1-f; Node/ip-10-0-1-g; Node/ip-10-0-1-h; Node/ip-10-0-1-i |
| f-380248bc3f40 | low | cost | 2 EBS volumes totalling 1700 GiB are on gp2, which costs more than gp3 for the same storage | $40 | medium | k8s.cost.ebs-gp2-where-gp3-is-cheaper | PersistentVolume/pvc-ledger-archive; PersistentVolume/pvc-analytics-scratch |
| f-058a0b2b43f6 | low | config | Add resource governance to namespace api | — | low | k8s.namespace.no-resource-governance | Namespace/api |
| f-0cbb0e17716f | low | security | Disable default SA token automount on payments/payments-gateway | — | low | k8s.workload.default-sa-token-automount | Deployment/payments/payments-gateway |
| f-0f5d9bf254a2 | low | security | Namespace api has no upstream NetworkPolicy — verify its Cilium policy CRDs | — | medium | k8s.namespace.no-network-policy | Namespace/api |
| f-1ce1b4c10535 | low | security | Disable default SA token automount on workers/webhook-dispatcher | — | low | k8s.workload.default-sa-token-automount | Deployment/workers/webhook-dispatcher |
| f-1d2d72d53137 | low | security | Disable default SA token automount on api/search-indexer | — | low | k8s.workload.default-sa-token-automount | Deployment/api/search-indexer |
| f-23977455f4df | low | config | Add resource governance to namespace payments | — | low | k8s.namespace.no-resource-governance | Namespace/payments |
| f-29e495848160 | low | config | Add resource governance to namespace workers | — | low | k8s.namespace.no-resource-governance | Namespace/workers |
| f-2dfd0e7bff3f | low | reliability | Single replica without PDB: workers/licensed-etl | — | medium | k8s.workload.single-replica-no-pdb | StatefulSet/workers/licensed-etl |
| f-38b56f608b04 | low | cost | Node pool r6i.4xlarge: up to 1 node of request-slack — verify usage before reclaiming | unpriced | medium | k8s.cost.node-headroom | Node/ip-10-0-2-a; Node/ip-10-0-2-b; Node/ip-10-0-2-c |
| f-3a88f9c0cd04 | low | security | Namespace monitoring has no upstream NetworkPolicy — verify its Cilium policy CRDs | — | medium | k8s.namespace.no-network-policy | Namespace/monitoring |
| f-419497d16695 | low | reliability | Add health probes to monitoring/node-exporter | — | low | k8s.workload.no-probes | Deployment/monitoring/node-exporter |
| f-4a5d593fb699 | low | security | Make the root filesystem read-only for workers/risk-batch-processor | — | medium | k8s.workload.writable-root-filesystem | Deployment/workers/risk-batch-processor |
| f-4e3bc6910d02 | low | reliability | Add health probes to api/auth-service | — | low | k8s.workload.no-probes | Deployment/api/auth-service |
| f-5004381bb1d3 | low | security | Make the root filesystem read-only for default/legacy-cron-runner | — | medium | k8s.workload.writable-root-filesystem | Deployment/default/legacy-cron-runner |
| f-507584056829 | low | security | Disable default SA token automount on api/auth-service | — | low | k8s.workload.default-sa-token-automount | Deployment/api/auth-service |
| f-6a299ed4fbf0 | low | security | Disable default SA token automount on default/legacy-cron-runner | — | low | k8s.workload.default-sa-token-automount | Deployment/default/legacy-cron-runner |
| f-723b76447261 | low | reliability | Add health probes to default/legacy-cron-runner | — | low | k8s.workload.no-probes | Deployment/default/legacy-cron-runner |
| f-72b028e08d42 | low | reliability | Single replica without PDB: default/legacy-cron-runner | — | medium | k8s.workload.single-replica-no-pdb | Deployment/default/legacy-cron-runner |
| f-770d026ea370 | low | cost | Node pool m6i.xlarge: up to 2 nodes of request-slack — verify usage before reclaiming | unpriced | medium | k8s.cost.node-headroom | Node/ip-10-0-1-a; Node/ip-10-0-1-b; Node/ip-10-0-1-c; Node/ip-10-0-1-d; Node/ip-10-0-1-e; Node/ip-10-0-1-f; Node/ip-10-0-1-g; Node/ip-10-0-1-h; Node/ip-10-0-1-i |
| f-797eeb071701 | low | reliability | 1 pod in workers has no controller | — | medium | k8s.reliability.unmanaged-pod | Pod/workers/debug-shell-ondemand |
| f-79d3c2f7e473 | low | config | 2 finished Jobs in workers will never be cleaned up | — | low | k8s.config.job-no-ttl | Job/workers/acme-backfill-0114; Job/workers/acme-schema-migrate-0117 |
| f-7b3aeab57996 | low | security | Secret material reaches payments/payments-gateway through the environment | — | medium | k8s.workload.secret-in-env-var | Deployment/payments/payments-gateway |
| f-7cb250877d80 | low | security | Namespace workers has no upstream NetworkPolicy — verify its Cilium policy CRDs | — | medium | k8s.namespace.no-network-policy | Namespace/workers |
| f-8380b8f3ff8b | low | config | CronJob workers/acme-nightly-reconcile sets no startingDeadlineSeconds | — | low | k8s.config.cronjob-no-starting-deadline | CronJob/workers/acme-nightly-reconcile |
| f-8c3a3bb8cf4a | low | reliability | Nodes report 2 different kubelet minor versions (1.29, 1.31) | — | high | k8s.reliability.node-version-skew | Node/ip-10-0-2-c; Node/ip-10-0-1-a; Node/ip-10-0-1-b; Node/ip-10-0-1-c; Node/ip-10-0-1-d; Node/ip-10-0-1-e; Node/ip-10-0-1-f; Node/ip-10-0-1-g; Node/ip-10-0-1-h; Node/ip-10-0-1-i; Node/ip-10-0-2-a; Node/ip-10-0-2-b |
| f-92378a29bcbd | low | reliability | Single replica without PDB: payments/payments-ledger-db | — | medium | k8s.workload.single-replica-no-pdb | StatefulSet/payments/payments-ledger-db |
| f-989158c7acd8 | low | security | Move default/legacy-cron-runner out of the default namespace | — | low | k8s.namespace.default-namespace-in-use | Deployment/default/legacy-cron-runner |
| f-990a9d899da0 | low | security | Disable default SA token automount on workers/ledger-reconciler | — | low | k8s.workload.default-sa-token-automount | Deployment/workers/ledger-reconciler |
| f-a23774f3cbc0 | low | config | ClusterRoleBinding acme-legacy-reporting names a role this reading did not find | — | low | k8s.rbac.roleref-unresolved | ClusterRoleBinding/acme-legacy-reporting |
| f-a4c78812a9e5 | low | security | Make the root filesystem read-only for api/api-gateway | — | medium | k8s.workload.writable-root-filesystem | Deployment/api/api-gateway |
| f-a85f78cb6063 | low | config | Deployment api/auth-service declares an environment variable twice | — | low | k8s.config.duplicate-env-var | Deployment/api/auth-service |
| f-abf66312763e | low | reliability | DaemonSet monitoring/acme-log-agent reports 2 pods running on nodes it does not select | — | low | k8s.reliability.daemonset-misscheduled | DaemonSet/monitoring/acme-log-agent |
| f-afab58f65d7e | low | config | Budget payments/payments-orchestrator-pdb matches no pods | — | low | k8s.config.pdb-selects-no-pods | PodDisruptionBudget/payments/payments-orchestrator-pdb |
| f-b7a81b6c303a | low | security | Disable default SA token automount on monitoring/node-exporter | — | low | k8s.workload.default-sa-token-automount | Deployment/monitoring/node-exporter |
| f-d3245733acee | low | security | Disable default SA token automount on payments/payments-orchestrator | — | low | k8s.workload.default-sa-token-automount | Deployment/payments/payments-orchestrator |
| f-d5596225b087 | low | security | Make the root filesystem read-only for api/auth-service | — | medium | k8s.workload.writable-root-filesystem | Deployment/api/auth-service |
| f-d61e807576a9 | low | reliability | Add health probes to payments/payments-orchestrator | — | low | k8s.workload.no-probes | Deployment/payments/payments-orchestrator |
| f-e399e6ba15a1 | low | config | Add resource governance to namespace monitoring | — | low | k8s.namespace.no-resource-governance | Namespace/monitoring |
| f-e4bf52323dca | low | security | Confirm host access is expected for monitoring/node-exporter | — | medium | k8s.workload.privileged-host-access | Deployment/monitoring/node-exporter |
| f-e59861c4d9bf | low | reliability | Single replica without PDB: payments/payments-gateway | — | medium | k8s.workload.single-replica-no-pdb | Deployment/payments/payments-gateway |
| f-f04606ed1db1 | low | security | Namespace payments has no upstream NetworkPolicy — verify its Cilium policy CRDs | — | medium | k8s.namespace.no-network-policy | Namespace/payments |
| f-f6611ef63287 | low | security | Namespace default has no upstream NetworkPolicy — verify its Cilium policy CRDs | — | medium | k8s.namespace.no-network-policy | Namespace/default |
| f-fb263a044542 | low | security | Make the root filesystem read-only for monitoring/node-exporter | — | medium | k8s.workload.writable-root-filesystem | Deployment/monitoring/node-exporter |
| f-ff76c68d256c | low | security | Disable default SA token automount on api/api-gateway | — | low | k8s.workload.default-sa-token-automount | Deployment/api/api-gateway |
| f-71eeda6f8736 | info | cost | 9 m6i.xlarge nodes run on-demand where a Savings Plan is published | unpriced | high | k8s.cost.commitment-candidate | Node/ip-10-0-1-a; Node/ip-10-0-1-b; Node/ip-10-0-1-c; Node/ip-10-0-1-d; Node/ip-10-0-1-e; Node/ip-10-0-1-f; Node/ip-10-0-1-g; Node/ip-10-0-1-h |
| f-c23a8a6e996e | info | cost | 3 r6i.4xlarge nodes run on-demand where a Savings Plan is published | unpriced | high | k8s.cost.commitment-candidate | Node/ip-10-0-2-a; Node/ip-10-0-2-b; Node/ip-10-0-2-c |
| f-fd15521bee79 | info | config | 3 LoadBalancer Services set externalTrafficPolicy: Cluster | — | low | k8s.config.external-traffic-policy | Service/payments/legacy-checkout-lb; Service/payments/legacy-payments-lb; Service/payments/old-admin-lb |

## What these findings do not establish

Every finding above says what it rests on. These say what it does **not** settle, in the product's own words, and they are part of the finding rather than a disclaimer about it.

**k8s.config.cronjob-no-starting-deadline** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.config.duplicate-env-var** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.config.external-traffic-policy** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.config.governing-service-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.hpa-target-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.ingress-backend-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.ingressclass-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.job-no-ttl** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.config.pdb-selects-no-pods** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.pod-covered-by-two-pdbs** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.config.priorityclass-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.probe-port-not-declared** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.service-targetport-undeclared** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.serviceaccount-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.storageclass-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.config.topology-key-no-node-carries** — 2 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.cost.commitment-candidate** — 2 finding(s)

- The figure is computed from a dated public list price, not from your bill. No credential of yours was used and no invoice was read, so a negotiated rate, a private offer or a credit is invisible here.
- Whether a commitment already covers this footprint is a billing-account fact this product cannot see. A saving stated at the on-demand rate is wrong for the term of any plan that already applies.
- Identified is not realised. Nothing here has been reclaimed, and the arithmetic assumes the freed capacity is actually given up rather than absorbed elsewhere.

**k8s.cost.ebs-gp2-where-gp3-is-cheaper** — 1 finding(s)

- The figure is computed from a dated public list price, not from your bill. No credential of yours was used and no invoice was read, so a negotiated rate, a private offer or a credit is invisible here.
- Whether a commitment already covers this footprint is a billing-account fact this product cannot see. A saving stated at the on-demand rate is wrong for the term of any plan that already applies.
- Identified is not realised. Nothing here has been reclaimed, and the arithmetic assumes the freed capacity is actually given up rather than absorbed elsewhere.

**k8s.cost.idle-loadbalancer** — 3 finding(s)

- The figure is computed from a dated public list price, not from your bill. No credential of yours was used and no invoice was read, so a negotiated rate, a private offer or a credit is invisible here.
- Whether a commitment already covers this footprint is a billing-account fact this product cannot see. A saving stated at the on-demand rate is wrong for the term of any plan that already applies.
- Identified is not realised. Nothing here has been reclaimed, and the arithmetic assumes the freed capacity is actually given up rather than absorbed elsewhere.

**k8s.cost.instance-generation-lag** — 2 finding(s)

- The figure is computed from a dated public list price, not from your bill. No credential of yours was used and no invoice was read, so a negotiated rate, a private offer or a credit is invisible here.
- Whether a commitment already covers this footprint is a billing-account fact this product cannot see. A saving stated at the on-demand rate is wrong for the term of any plan that already applies.
- Identified is not realised. Nothing here has been reclaimed, and the arithmetic assumes the freed capacity is actually given up rather than absorbed elsewhere.

**k8s.cost.kubernetes-version-past-standard-support** — 1 finding(s)

- The dollar impact is zero on purpose. This is a candidate to investigate with real utilisation, not a saving: requests-only slack cannot tell an idle pool from one whose pods under-request against what they actually use, and acting on the second packs a cluster into an OOM.

**k8s.cost.node-headroom** — 2 finding(s)

- The dollar impact is zero on purpose. This is a candidate to investigate with real utilisation, not a saving: requests-only slack cannot tell an idle pool from one whose pods under-request against what they actually use, and acting on the second packs a cluster into an OOM.

**k8s.cost.overprovisioned-resources** — 10 finding(s)

- The figure is computed from a dated public list price, not from your bill. No credential of yours was used and no invoice was read, so a negotiated rate, a private offer or a credit is invisible here.
- Whether a commitment already covers this footprint is a billing-account fact this product cannot see. A saving stated at the on-demand rate is wrong for the term of any plan that already applies.
- Identified is not realised. Nothing here has been reclaimed, and the arithmetic assumes the freed capacity is actually given up rather than absorbed elsewhere.
- This rests on a measured window from a metrics source, so it is only as long as that source has been running: a young Prometheus reports a short window and the confidence says so. Without a usage source the rule emits nothing rather than guessing.
- Requests are compared against observed p95 with headroom, taking the busiest replica rather than the mean. It is a statement about reserved capacity, never about whether the workload is fast enough.

**k8s.namespace.default-namespace-in-use** — 1 finding(s)

- This reports what is not configured, which is not the same as what is not enforced. A CNI may carry segmentation in its own policy objects, which this product does not read, so the absence of an upstream NetworkPolicy is not the absence of isolation.
- An admission control governs what may be applied next. It says nothing about what is already running, which was admitted under whatever policy was in force at the time.

**k8s.namespace.no-network-policy** — 5 finding(s)

- This reports what is not configured, which is not the same as what is not enforced. A CNI may carry segmentation in its own policy objects, which this product does not read, so the absence of an upstream NetworkPolicy is not the absence of isolation.
- An admission control governs what may be applied next. It says nothing about what is already running, which was admitted under whatever policy was in force at the time.

**k8s.namespace.no-resource-governance** — 4 finding(s)

- This reports what is not configured, which is not the same as what is not enforced. A CNI may carry segmentation in its own policy objects, which this product does not read, so the absence of an upstream NetworkPolicy is not the absence of isolation.
- An admission control governs what may be applied next. It says nothing about what is already running, which was admitted under whatever policy was in force at the time.

**k8s.namespace.pss-admission-not-enforced** — 5 finding(s)

- This reports what is not configured, which is not the same as what is not enforced. A CNI may carry segmentation in its own policy objects, which this product does not read, so the absence of an upstream NetworkPolicy is not the absence of isolation.
- An admission control governs what may be applied next. It says nothing about what is already running, which was admitted under whatever policy was in force at the time.

**k8s.observed.alerts-firing** — 1 finding(s)

- This is sourced from a metrics endpoint, so its absence is a third state — not assessed — distinct from clean. When no source was reachable the rule emits nothing rather than an all-clear.
- Throttling is a ratio of period counters over the measured window. It is not a count of seconds a container spent throttled, and it is not a statement that anything was slow.

**k8s.observed.scrape-targets-down** — 1 finding(s)

- This is sourced from a metrics endpoint, so its absence is a third state — not assessed — distinct from clean. When no source was reachable the rule emits nothing rather than an all-clear.
- Throttling is a ratio of period counters over the measured window. It is not a count of seconds a container spent throttled, and it is not a statement that anything was slow.

**k8s.rbac.binding-subject-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.
- The bindings Kubernetes writes for itself are excluded: the label kubernetes.io/bootstrapping: rbac-defaults AND the exact upstream binding — name, role and subjects. Some name ServiceAccounts for cloud controllers a cluster never runs, so their absence is the distribution's. A labelled binding that is not the upstream one, or an unlabelled one, is reported.

**k8s.rbac.binding-to-builtin-subject** — 2 finding(s)

- An absence here is not an absence of the subject. Membership is decided outside the cluster — a client certificate's O=, an OIDC claim, a provider's IAM mapping, or for the unauthenticated identities the simple absence of a credential — so a reading with no such binding has not established that nobody holds it.
- Whether the grant is reachable was not established. Anonymous requests are accepted or refused by a control-plane flag a managed cluster does not expose, so a binding naming an unauthenticated subject may be live or may be unreachable, and this reading cannot tell those apart.
- Nothing here is a statement about the role's contents. This finding is about the subject a binding names; what the referenced role permits is a separate reading, and a harmless role bound to a dangerous subject is reported here exactly as a powerful one is.
- A permission is not a use. Nothing here says the grant was exercised; the snapshot carries no audit log and no request history.
- The bindings Kubernetes writes for itself are excluded: the label kubernetes.io/bootstrapping: rbac-defaults AND the exact binding the upstream bootstrap policy writes — its name, its role and its subjects, no more and no fewer. The label alone is not trusted, because anybody who can create a binding can set it; a labelled binding that is not the upstream one is reported like any other. A binding an installer created without that label is reported even where it is that installer's normal behaviour, because a rule that decided which installers to trust would be making a judgement this reading cannot support.

**k8s.rbac.cluster-admin-serviceaccount** — 1 finding(s)

- This names one role's rules and the bindings that activate it. It is not a total: a subject's effective permissions are the union over every binding that names it or any group it belongs to, and group membership is decided by the authenticator rather than by anything in the cluster.
- A permission is not a use. Nothing here says the grant was exercised; the snapshot carries no audit log and no request history.
- The bindings Kubernetes writes for itself are not counted as activating a role: the label kubernetes.io/bootstrapping: rbac-defaults AND the exact upstream binding — name, role and subjects. The label alone is not trusted. Two upstream bindings are counted anyway, because their roles may have been edited and the API server never removes a permission: one naming a broad group such as system:authenticated, and one whose role grants every verb on every resource and is not cluster-admin. A bootstrap role edited in any narrower way is not detected.

**k8s.rbac.dangerous-grant** — 3 finding(s)

- This names one role's rules and the bindings that activate it. It is not a total: a subject's effective permissions are the union over every binding that names it or any group it belongs to, and group membership is decided by the authenticator rather than by anything in the cluster.
- A permission is not a use. Nothing here says the grant was exercised; the snapshot carries no audit log and no request history.
- The bindings Kubernetes writes for itself are not counted as activating a role: the label kubernetes.io/bootstrapping: rbac-defaults AND the exact upstream binding — name, role and subjects. The label alone is not trusted. Two upstream bindings are counted anyway, because their roles may have been edited and the API server never removes a permission: one naming a broad group such as system:authenticated, and one whose role grants every verb on every resource and is not cluster-admin. A bootstrap role edited in any narrower way is not detected.

**k8s.rbac.roleref-unresolved** — 1 finding(s)

- The finding is that the reference resolves to nothing in this reading. It is not a prediction of what will happen: a pod created after the target went away behaves differently from one that has been running for a month on a token it already holds, and the snapshot cannot tell which it is looking at.
- This is an absence claim over the TARGET list, so it is made only when that list was actually read. A refused list produces silence here rather than a cluster that appears entirely broken.
- Kinds this product does not collect are excluded and counted, never reported as missing — an autoscaler may target an Argo Rollout or a KEDA ScaledObject, and calling those absent would fire on every cluster running one.

**k8s.reliability.autoscaler-floor-below-budget** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.condition-unchanged** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.container-restart-total** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.cronjob-no-recent-success** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.daemonset-misscheduled** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.node-drain-budget** — 3 finding(s)

- No pod here appeared as an endpoint entry in any EndpointSlice this reading saw, which is not evidence that they serve nothing — only that no slice this reading read named them.
- A PodDisruptionBudget gates voluntary eviction only. Node loss, force-deletion, `kubectl delete pod` and kubelet node-pressure eviction all bypass it, so this says nothing about what happens when a node dies.
- No duration is stated, and none can be. A floor derived from readiness probes inverts exactly where it is most dangerous — a workload with no probe would score fastest — and pod-recovery time is not service-downtime time.
- Nothing here is a claim about users or traffic. A pod matching a Service selector is not evidence it was in rotation, and a published endpoint is not a request.
- This is a statement about placement and mechanism, not a rating. There is no survival score, no single-point-of-failure verdict and no dollar figure, because the snapshot holds no traffic, revenue or SLA data.
- Whether the control plane would evict at all is unreadable: node-monitor-grace-period and DefaultTolerationSeconds are provider-set flags on a managed cluster, and taint-based eviction can be disabled outright.

**k8s.reliability.node-drain-unmanaged-pod** — 1 finding(s)

- A PodDisruptionBudget gates voluntary eviction only. Node loss, force-deletion, `kubectl delete pod` and kubelet node-pressure eviction all bypass it, so this says nothing about what happens when a node dies.
- No duration is stated, and none can be. A floor derived from readiness probes inverts exactly where it is most dangerous — a workload with no probe would score fastest — and pod-recovery time is not service-downtime time.
- Nothing here is a claim about users or traffic. A pod matching a Service selector is not evidence it was in rotation, and a published endpoint is not a request.
- This is a statement about placement and mechanism, not a rating. There is no survival score, no single-point-of-failure verdict and no dollar figure, because the snapshot holds no traffic, revenue or SLA data.
- Whether the control plane would evict at all is unreadable: node-monitor-grace-period and DefaultTolerationSeconds are provider-set flags on a managed cluster, and taint-based eviction can be disabled outright.

**k8s.reliability.node-loss-feasibility** — 1 finding(s)

- The model checks a SUBSET of the scheduler's predicates, which is what makes the negative sound: a model more permissive than the scheduler finding no fit means the scheduler finds none either. The positive does not follow and is never asserted — that no pod here is listed is not a claim that any pod would be placed.
- The scheduler's own configuration is unreadable on a managed cluster, admission injects containers into the pod that actually gets placed, and per-node volume-attach limits and max-pods are not read. Preemption is unmodelled.
- No cost follows from this. Not a node count, not a smaller configuration, not a figure — a pod having nowhere to go says nothing about what the cluster should be sized at.

**k8s.reliability.node-version-skew** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.pod-not-ready** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.pvc-below-request** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.replicas-below-desired** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.rwo-volume-shared** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.service-no-ready-endpoints** — 4 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.unmanaged-pod** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.reliability.zone-loss-feasibility** — 1 finding(s)

- The model checks a SUBSET of the scheduler's predicates, which is what makes the negative sound: a model more permissive than the scheduler finding no fit means the scheduler finds none either. The positive does not follow and is never asserted — that no pod here is listed is not a claim that any pod would be placed.
- The scheduler's own configuration is unreadable on a managed cluster, admission injects containers into the pod that actually gets placed, and per-node volume-attach limits and max-pods are not read. Preemption is unmodelled.
- No cost follows from this. Not a node count, not a smaller configuration, not a figure — a pod having nowhere to go says nothing about what the cluster should be sized at.

**k8s.reliability.zone-pinned-volume** — 1 finding(s)

- This is a state read at one instant. The snapshot has no time axis, so nothing here is a rate, a trend or a duration — a restart count is a total the kubelet reports, not a frequency.
- No cause is asserted. The reading records what the cluster says about itself; why it says it is outside what a read-only client can see.

**k8s.upgrade.deprecated-api-served** — 1 finding(s)

- This says what the cluster will stop SERVING, never what will break. When a version is removed the existing objects keep being served at the surviving version; what breaks is clients — YAML in a repository, a Helm chart, a controller's library, a CI pipeline — and none of those is inside a kubeconfig.
- No workload is named as being at risk, deliberately. The object is precisely the thing that survives a version removal, so naming one would assert the opposite of what is true.
- What is SERVED is not what is APPLIED. `last-applied-configuration` would be the obvious source for the latter and is refused: it is absent on every GitOps cluster, nothing updates it on a storage migration, and it holds the entire applied manifest.
- A group/version string is not a stable identity across releases — one API was removed in 1.22 and reintroduced in 1.28 — so the removal schedule is read as a dated dataset with a version and a stamp, not as a permanent fact.
- Silence from this family means these checks ran and found nothing. It is not a statement that the upgrade will succeed.

**k8s.upgrade.node-pool-cannot-roll** — 1 finding(s)

- This says what the cluster will stop SERVING, never what will break. When a version is removed the existing objects keep being served at the surviving version; what breaks is clients — YAML in a repository, a Helm chart, a controller's library, a CI pipeline — and none of those is inside a kubeconfig.
- No workload is named as being at risk, deliberately. The object is precisely the thing that survives a version removal, so naming one would assert the opposite of what is true.
- What is SERVED is not what is APPLIED. `last-applied-configuration` would be the obvious source for the latter and is refused: it is absent on every GitOps cluster, nothing updates it on a storage migration, and it holds the entire applied manifest.
- A group/version string is not a stable identity across releases — one API was removed in 1.22 and reintroduced in 1.28 — so the removal schedule is read as a dated dataset with a version and a stamp, not as a permanent fact.
- Silence from this family means these checks ran and found nothing. It is not a statement that the upgrade will succeed.

**k8s.workload.allow-privilege-escalation** — 5 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.capabilities-not-dropped** — 5 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.default-sa-token-automount** — 9 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- A declared setting is not a demonstrated behaviour. Nothing here says this workload behaved in any particular way, only what its specification declares.

**k8s.workload.image-digest-drift** — 1 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.missing-resource-requests** — 1 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.mutable-image-tags** — 1 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.no-anti-affinity** — 6 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- A declared setting is not a demonstrated behaviour. Nothing here says this workload behaved in any particular way, only what its specification declares.

**k8s.workload.no-probes** — 4 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.privileged-host-access** — 1 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- A declared setting is not a demonstrated behaviour. Nothing here says this workload behaved in any particular way, only what its specification declares.

**k8s.workload.runs-as-root** — 5 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.seccomp-not-enforced** — 5 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.

**k8s.workload.secret-in-env-var** — 1 finding(s)

- The Secret itself was not read. This is the reference in the pod template — a name and a key — so nothing here says what the value is, whether it is sensitive, or whether it is set at all. A Secret holding a feature flag reads exactly like one holding a database password.
- Nothing leaked, as far as this reading knows. It is a declaration in a specification, not an observation of a process, a log line or a request. No disclosure is claimed and none was looked for.
- Whether the Secret exists was not checked. A reference to an absent Secret produces a pod that will not start, which is a different finding this reading cannot make.
- A mounted file is not automatically safer. The control asks for a shape; a Secret mounted world-readable into a shared volume is worse than an environment variable, and the mode of any mount is outside what this finding examined.
- This is the workload's declared pod template, not what is running. Admission can inject containers and rewrite environments, so the pod the scheduler placed may differ from the one described here.

**k8s.workload.single-replica-no-pdb** — 5 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- A declared setting is not a demonstrated behaviour. Nothing here says this workload behaved in any particular way, only what its specification declares.

**k8s.workload.writable-root-filesystem** — 5 finding(s)

- This is read from the workload's declared pod template, not from what is running. Admission may inject or mutate containers, so the pod the scheduler placed is not always the pod described here.
- The count is per container and states its denominator: a workload where some containers set a field and others do not says how many of how many, because a partial workload rendered as a whole one is the same defect as an absence rendered as a pass.
- A declared setting is not a demonstrated behaviour. Nothing here says a container attempted anything, only what its specification permits.
