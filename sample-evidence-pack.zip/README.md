> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# Evidence pack — acme-pay-prod

This directory is the evidence base for the controls Shoalcheck's rules map to: the observations one read-only
reading of the cluster produced, what each observation rests on, what the reading could not examine, and
every request it issued. It is evidence, not an opinion. Interpreting an observation against a control's text
is the auditor's work, and nothing here does it for them: there is no verdict, no ratio and no figure that ranks the cluster.

## The reading

- Cluster: acme-pay-prod
- Provider: EKS · eu-central-1
- Taken: 2026-09-15T05:28:50Z (a single moment, not a continuous watch)
- Engine: 0.23.0, 103 rules and analyzers in the build
- Reference data api-removals: version 2026-08-30 (embedded)
- Reference data kubeversions: version 2026-08-31 (embedded)
- Reference data pricing: version 2026-09 (embedded)
- Benchmark named by the CIS-K8s assessment: CIS Kubernetes Benchmark v1.9 (Section 5 subset). Control titles in this pack are Shoalcheck's own; no benchmark text is reproduced.

## What was read, and what was not

Collected (read successfully): server-resources, nodes, namespaces, deployments, statefulsets, daemonsets, pods, services, endpointslices, poddisruptionbudgets, clusterrolebindings, rolebindings, clusterroles, roles, serviceaccounts, networkpolicies, resourcequotas, limitranges, persistentvolumes, persistentvolumeclaims, ingresses, horizontalpodautoscalers, storageclasses, ingressclasses, priorityclasses, jobs, cronjobs.

Every kind the reading asked for was read; denied.md says so too.

## Files

- `controls/<framework>/<control>.md` — 58 file(s), every framework the report maps: the observations mapped to the control, what each rests on, and what could not be examined for it.
- `findings.md`, `findings.csv` — every finding of the reading, the same handoff `shoalcheck audit --export-md/--export-csv` writes.
- `denied.md` — what the reading could not examine, wholesale and per finding.
- `trace.md` — every request the reading issued, grouped by resource and verb.
- `report.json` — the report this pack was built from, byte for byte.
- `manifest.json` — a SHA-256 for every file and for the input. Signed by this install's key, fingerprint sha256:8ef78d391dfd8da7: the operator produces it with `shoalcheck evidence pubkey` (or sends their install.pub), and you run `shoalcheck evidence verify --pack <dir> --pub install.pub`. The signature says these bytes are the ones that key signed — not that the reading was truthful, which cluster it read, or which person ran it.

## How to read a control file

`Status` is what the machine check observed and names the rule that observed it — FAIL means a mapped finding exists, PASS means a
check ran and produced none, MANUAL means no automated check exists for the control in this build, NA means the control is
out of a read-only API client's reach on a managed cluster. SOC 2 and PCI DSS rows carry observations and no machine status
at all. In every case the sentence under the status says what it rests on.
