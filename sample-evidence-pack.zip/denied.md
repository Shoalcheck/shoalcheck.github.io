> **Illustrative sample.** acme-pay-prod is a fictional cluster: this is the real `shoalcheck evidence` run over a synthetic reading, shown so you can see what a pack contains. No observation here describes anybody's infrastructure.

# What this reading could not examine

Read successfully: server-resources, nodes, namespaces, deployments, statefulsets, daemonsets, pods, services, endpointslices, poddisruptionbudgets, clusterrolebindings, rolebindings, clusterroles, roles, serviceaccounts, networkpolicies, resourcequotas, limitranges, persistentvolumes, persistentvolumeclaims, ingresses, horizontalpodautoscalers, storageclasses, ingressclasses, priorityclasses, jobs, cronjobs.

Every kind the reading asked for was read.

No finding in this reading rests on a refused read.
